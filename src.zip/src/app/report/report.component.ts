import { Component, OnInit } from '@angular/core';
import { report } from '../report';
import {ApiService} from '../api.service'
import {punching} from '../punching';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {

  constructor(private api: ApiService) { }
selectedDate: report = {logdate: null};
logdate: any;
myDate: string = "";
punchingdata: punching;
Isrecord: Boolean = false;
Isrecordnot: Boolean = false;
isReport: Boolean = false;
reportdate: string = "";
message: string = "";
title = 'angulardatatables';
dtOptions: DataTables.Settings = {};
ngOnInit() {
 
    
  }

  getReport(form)
  {
    this.isReport = true;
    if(form.valid)
    {
      this.reportdate = this.selectedDate.logdate;
     // debugger;
      this.myDate = (new Date(this.selectedDate.logdate).getMonth() + 1) + "/" + (new Date(this.selectedDate.logdate).getDate()) + "/" + (new Date(this.selectedDate.logdate).getFullYear());
    //  console.log(JSON.stringify(this.myDate, null, " "));
      //this.logdate = {"logdate" : this.myDate};
      //this.logdate = JSON.stringify(this.logdate, null, " ")
     // console.log(this.logdate);
      this.selectedDate.logdate = this.myDate;
      console.log(this.selectedDate);
this.api.getPunchingData(this.selectedDate).subscribe((punchingdata: any) => {
 // debugger;
 if(Object.keys(punchingdata).length > 0 )
 {
   this.Isrecord = true;
   this.Isrecordnot = false;
  this.punchingdata = punchingdata;
  this.dtOptions = {
    pagingType: 'full_numbers',
    pageLength: 5,
    processing: true
  };
  
 }
 else
 {
  this.Isrecord = false;
  this.Isrecordnot = true;
  this.message = "No record found";
 }
    console.log(punchingdata);
})

    //  console.log(this.selectedDate.reportdate);
    }
  }

}
