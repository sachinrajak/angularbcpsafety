export class punching {
    id?: string;
    email: string;
    name:string;
    mobile:string;
    location:string;
    familycount:number;
    covid: string;
    locality: string;
    aarogya: string;
    remarks?: string;
}