import { Component, OnInit } from '@angular/core';
import { register } from '../register';
import {ApiService} from '../api.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private apiService:ApiService) { }

  issuccessMessage: boolean = false;
  iserrorMessage: boolean = false;
  api_message: string = "";
  selectedUser: register = { name:null, email: null, mobile: null, location: null, familycount: null}

  ngOnInit(): void {
  }

  NewRegistration(form){
    if(form.valid)
    {
    console.log(JSON.stringify(form.value, null, " "));
    this.apiService.createUser(form.value).subscribe((statusstring: string)=>{
      if(statusstring == "1")
      {
        this.issuccessMessage = true;
        this.iserrorMessage = false;
        this.api_message = "User successfully registered.";
      }
      if(statusstring == "2")
      {
        this.issuccessMessage = false;
        this.iserrorMessage = true;
        this.api_message = "User already registered.";
      }
      console.log(statusstring);
    })
    }
  }
}
