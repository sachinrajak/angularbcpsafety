
import { Component, OnInit } from '@angular/core';
import { punching } from '../punching'
import {register} from '../register';
import {ActivatedRoute, Router } from '@angular/router';
import {ApiService} from '../api.service';



@Component({
  selector: 'app-punching',
  templateUrl: './punching.component.html',
  styleUrls: ['./punching.component.css']
})
export class PunchingComponent implements OnInit {
  
  constructor(private route: ActivatedRoute, private api:ApiService, private router: Router ) { }
  getEmail: string = "";
  issuccessMessage: boolean = false;
  iserrorMessage: boolean = false;
  isAdmin: Boolean = false;
  api_message: string = "";
selectedPunching: punching = { email: null, name: null, mobile: null, location: null, familycount: null, covid: null, locality: null, aarogya: null, remarks: null}
  ngOnInit(): void {
   this.getEmail = this.route.snapshot.paramMap.get('email');
   this.selectedPunching.email = this.getEmail;

this.api.getUserDetail(this.getEmail).subscribe((userdetail: register) => {
  console.log(userdetail);
  console.log(Object.keys(userdetail).length);
  if(Object.keys(userdetail).length > 0)
  {
  this.selectedPunching.name = userdetail[0].name;
  this.selectedPunching.mobile = userdetail[0].mobile;
  this.selectedPunching.location = userdetail[0].location;
  this.selectedPunching.familycount = userdetail[0].familycount;
  if(userdetail[0].role == "1")
  {
    this.isAdmin = true;
  }
  else
  {this.isAdmin = false;}
  }
  else{
    this.issuccessMessage = false;
    this.iserrorMessage = true;
    this.api_message = "Data not available, try again.";
  }
})

   this.selectedPunching.covid = "Yes";
   this.selectedPunching.locality="No";
   this.selectedPunching.aarogya="Yes";

  }

  submitPunching(form){
    console.log(JSON.stringify(this.selectedPunching, null, " "));
    this.api.dailyPunching(this.selectedPunching).subscribe((statusstring: string) => {
      if(statusstring == "1")
      {
        this.issuccessMessage = true;
        this.iserrorMessage = false;
        this.api_message = "Record saved successfully.";
      }
      if(statusstring == "0")
      {
        this.issuccessMessage = false;
        this.iserrorMessage = true;
        this.api_message = "Error occured, please try again.";
      }
      console.log(statusstring);
    })
  }

  showReport(){
    this.router.navigate(['/report']);
  }

}
