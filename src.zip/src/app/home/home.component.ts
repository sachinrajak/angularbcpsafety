import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ApiService} from '../api.service';
import {register} from '../register';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router: Router, private api: ApiService) { }
selectedEmail: string ="";
iserrorMessage: boolean = false;
api_message: string = "";
  ngOnInit(): void {
    this.selectedEmail = "";
  }

  NewUser(){
    
    console.log('new user call');
      this.router.navigate(['/register']);
  }

  ExistingUser(form){
    if(form.valid)
    {
      this.api.getUserDetail(this.selectedEmail).subscribe((userdetail: register) => {
        if(Object.keys(userdetail).length > 0)
        {
          this.router.navigate(['/punching',{email: this.selectedEmail}]);
        }
        else
        {
          this.iserrorMessage = true;
    this.api_message = "User is not registered, kindly register yourself first.";
        }
      })
   
    }
}

}
