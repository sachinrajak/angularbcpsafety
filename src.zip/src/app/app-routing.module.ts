import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { PunchingComponent } from './punching/punching.component';
import { ReportComponent } from './report/report.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  { path: 'register', component: RegisterComponent },
  { path: 'punching', component: PunchingComponent },
  { path: 'report', component: ReportComponent },
  { path: 'home', component:HomeComponent},
  { path: '', component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
