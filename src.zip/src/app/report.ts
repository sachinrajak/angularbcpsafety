export class report{
    logdate: string;
}



