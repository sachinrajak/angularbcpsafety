export class register{
    id?: string;
    name: string;
    email: string;
    mobile: string;
    location: string;
    familycount: number;
    role?: string;
}