import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {register} from './register';
import {punching} from './punching';
import { report } from './report';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  user_api_service = "http://127.0.0.1:3004";
  safety_api_service = "http://127.0.0.1:3005";
  
  constructor(private httpclient: HttpClient) { }

  createUser(User: register): Observable<string>{
    return this.httpclient.post<string>(`${this.user_api_service}/registerUser`, User);
  }

  getUserDetail(id: string): Observable<register>{
    return this.httpclient.get<register>(`${this.user_api_service}/getuser/`+id)
  }

  dailyPunching(Data: punching): Observable<string>{
    return this.httpclient.post<string>(`${this.safety_api_service}/LogData`, Data);
  }

  getPunchingData(dailyDate: report): Observable<punching[]>{
    return this.httpclient.post<punching[]>(`${this.safety_api_service}/getuserdetails`, dailyDate);
  }
}
